List<String> emoLabels = ['angry', 'disgust:', 'fear', 'happy', 'sad', 'surprise', 'neutral'];
int emoNumClass = emoLabels.length;
